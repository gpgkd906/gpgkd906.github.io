# Aチームプレゼン資料

再生方法：

最新版のnodeJSとPHPをインストール。

当フォルダ配下で下記コマンドを実行

    npm run server
